<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer for tool_ghostead.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_ghostead\output;

defined('MOODLE_INTERNAL') || die();

/**
 * Plugin renderer.
 */
class renderer extends \plugin_renderer_base {

    /**
     * Render the report page content.
     *
     * @param report $report Renderable.
     * @return string HTML.
     */
    protected function render_report(report $report) {
        return $this->render_from_template('tool_ghostead/report', $report->export_for_template($this));
    }
}
