<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderable for the GhostEAD report page.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_ghostead\output;

defined('MOODLE_INTERNAL') || die();

use moodle_url;
use renderable;
use renderer_base;
use templatable;

/**
 * Data for the tool_ghostead/report template.
 */
class report implements renderable, templatable {

    /** @var moodle_url Page URL. */
    private $pageurl;
    /** @var int Selected category id. */
    private $categoryid;
    /** @var \stdClass[] Scanner rows. */
    private $rows;
    /** @var int Number of analysed courses. */
    private $total;
    /** @var string[] Category id => (HTML formatted) name. */
    private $categories;
    /** @var bool Whether course sizes were loaded. */
    private $showsize;
    /** @var bool Whether the archive category is ready to use. */
    private $archiveok;

    /**
     * Constructor.
     *
     * @param moodle_url $pageurl Page URL.
     * @param int $categoryid Selected category (0 = all).
     * @param array $rows Rows returned by the scanner.
     * @param int $total Courses analysed.
     * @param array $categories Category id => name.
     * @param bool $showsize Show course sizes.
     * @param bool $archiveok Archive category configured and existing.
     */
    public function __construct(moodle_url $pageurl, int $categoryid, array $rows, int $total,
            array $categories, bool $showsize, bool $archiveok) {
        $this->pageurl = $pageurl;
        $this->categoryid = $categoryid;
        $this->rows = $rows;
        $this->total = $total;
        $this->categories = $categories;
        $this->showsize = $showsize;
        $this->archiveok = $archiveok;
    }

    /**
     * Turn HTML-formatted text into plain text (Mustache escapes on output).
     *
     * @param string $text Text possibly containing entities or tags.
     * @return string
     */
    private static function plain(string $text): string {
        return html_entity_decode(strip_tags($text), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Export the data for the template.
     *
     * @param renderer_base $output Renderer.
     * @return array
     */
    public function export_for_template(renderer_base $output) {
        $hiddencount = 0;
        $rows = [];

        foreach ($this->rows as $row) {
            if (!$row->visible) {
                $hiddencount++;
            }

            $lastaccess = $row->lastaccess ?
                userdate($row->lastaccess, get_string('strftimedatefullshort', 'langconfig')) :
                get_string('never', 'tool_ghostead');
            $category = isset($this->categories[$row->category]) ? self::plain($this->categories[$row->category]) : '-';
            $meta = [
                $row->shortname,
                $category,
                get_string('lastaccess', 'tool_ghostead') . ': ' . $lastaccess,
                $row->students . ' ' . \core_text::strtolower(get_string('students', 'tool_ghostead')),
                $row->teachers . ' ' . \core_text::strtolower(get_string('teachers', 'tool_ghostead')),
                $row->activities . ' ' . \core_text::strtolower(get_string('activities', 'tool_ghostead')),
            ];
            if ($this->showsize) {
                $meta[] = $row->size === null ? '-' : display_size($row->size);
            }

            $reasons = [];
            foreach ($row->reasons as $code) {
                $reasons[] = ['text' => get_string('reason_' . $code, 'tool_ghostead')];
            }

            $name = format_string($row->fullname, true, ['escape' => false]);
            $rows[] = [
                'id' => (int) $row->id,
                'url' => (new moodle_url('/course/view.php', ['id' => $row->id]))->out(false),
                'name' => $name,
                'namelabel' => $name,
                'meta' => implode(' · ', $meta),
                'reasons' => $reasons,
                'ishidden' => !$row->visible,
                'score' => (int) $row->score,
                'scoreclass' => $row->score >= 85 ? ' gh-high' : ($row->score >= 70 ? ' gh-mid' : ''),
                'scoretitle' => get_string('score', 'tool_ghostead') . ': ' . get_string('score_help', 'tool_ghostead'),
            ];
        }

        $categories = [];
        foreach ($this->categories as $id => $name) {
            $categories[] = [
                'value' => (int) $id,
                'name' => self::plain($name),
                'selected' => ((int) $id === $this->categoryid),
            ];
        }

        return [
            'actionurl' => $this->pageurl->out_omit_querystring(),
            'sesskey' => sesskey(),
            'categoryid' => $this->categoryid,
            'stats' => [
                ['value' => $this->total, 'label' => get_string('statanalysed', 'tool_ghostead')],
                ['value' => count($this->rows), 'label' => get_string('statghosts', 'tool_ghostead')],
                ['value' => $hiddencount, 'label' => get_string('stathidden', 'tool_ghostead')],
            ],
            'categories' => $categories,
            'hasrows' => !empty($rows),
            'count' => count($rows),
            'rows' => $rows,
            'archiveok' => $this->archiveok,
            'canconfig' => has_capability('moodle/site:config', \context_system::instance()),
            'settingsurl' => (new moodle_url('/admin/settings.php', ['section' => 'tool_ghostead_settings']))->out(false),
        ];
    }
}
