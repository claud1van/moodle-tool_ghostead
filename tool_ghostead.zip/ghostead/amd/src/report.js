// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD report: select all, live counters and a confirmation before archiving.
 *
 * @module     tool_ghostead/report
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {

    var CHECKED = 'input[name="courseids[]"]:checked';

    return {
        /**
         * Initialise the report form.
         *
         * @param {Object} S Language strings: selectall, clear, selected, hide, archive, confirm, courses.
         */
        init: function(S) {
            var form = document.getElementById('ghostead-form');
            if (!form) {
                return;
            }
            var boxes = form.querySelectorAll('input[name="courseids[]"]');
            var all = document.getElementById('ghostead-selectall');
            var hide = document.getElementById('ghostead-hide');
            var archive = document.getElementById('ghostead-archive');
            var count = document.getElementById('ghostead-count');
            var total = boxes.length;

            var refresh = function() {
                var n = form.querySelectorAll(CHECKED).length;
                hide.disabled = (n === 0);
                archive.disabled = (n === 0) || archive.hasAttribute('data-locked');
                hide.textContent = S.hide + (n ? ' (' + n + ')' : '');
                archive.textContent = S.archive + (n ? ' (' + n + ')' : '');
                all.textContent = (n === total) ? S.clear : S.selectall;
                count.textContent = n ? (n + ' ' + S.selected + ' / ' + total) : (total + ' ' + S.courses);
            };

            all.addEventListener('click', function() {
                var check = form.querySelectorAll(CHECKED).length !== total;
                Array.prototype.forEach.call(boxes, function(box) {
                    box.checked = check;
                });
                refresh();
            });

            form.addEventListener('change', refresh);

            // Clicking anywhere on a row (except links and the checkbox itself) toggles it.
            form.addEventListener('click', function(e) {
                var row = e.target.closest ? e.target.closest('.gh-row') : null;
                if (row && !e.target.closest('a') && e.target.tagName !== 'INPUT') {
                    var box = row.querySelector('input[type="checkbox"]');
                    box.checked = !box.checked;
                    refresh();
                }
            });

            archive.addEventListener('click', function(e) {
                if (!window.confirm(S.confirm)) {
                    e.preventDefault();
                }
            });

            refresh();
        }
    };
});
