<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - ghost courses report and bulk actions.
 *
 * Written to run on Moodle 3.7+ (PHP 7.1+). This file only gets data and checks access;
 * markup lives in templates/report.mustache (rendered by classes/output) and behaviour in
 * amd/src/report.js. Styles are in styles.css, scoped to the plugin's own classes.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

use core\output\notification;
use tool_ghostead\local\actions;
use tool_ghostead\local\scanner;

$categoryid = optional_param('category', 0, PARAM_INT);
$bulkaction = optional_param('bulkaction', '', PARAM_ALPHA);
$courseids = optional_param_array('courseids', [], PARAM_INT);

admin_externalpage_setup('tool_ghostead', '', ['category' => $categoryid]);
require_capability('tool/ghostead:manage', context_system::instance());

$result = scanner::scan($categoryid);
$rows = $result['rows'];
$archivecat = (int) get_config('tool_ghostead', 'archivecategory');
$archiveok = $archivecat > 0 && core_course_category::get($archivecat, IGNORE_MISSING);

// Handle bulk actions (POST + sesskey). Only courses currently listed as ghosts are accepted.
if ($bulkaction !== '' && data_submitted() && confirm_sesskey()) {
    $courseids = array_values(array_intersect($courseids, array_keys($rows)));

    if (empty($courseids)) {
        redirect($PAGE->url, get_string('nocourseselected', 'tool_ghostead'), null, notification::NOTIFY_WARNING);
    }

    if ($bulkaction === 'hide') {
        $n = actions::hide($courseids);
        redirect($PAGE->url, get_string('hide_done', 'tool_ghostead', $n), null, notification::NOTIFY_SUCCESS);
    }

    if ($bulkaction === 'archive') {
        if (!$archiveok) {
            redirect($PAGE->url, get_string('noarchivecategory', 'tool_ghostead'), null, notification::NOTIFY_ERROR);
        }
        $n = actions::archive($courseids, $archivecat);
        redirect($PAGE->url, get_string('archive_done', 'tool_ghostead', $n), null, notification::NOTIFY_SUCCESS);
    }
}

$showsize = (bool) get_config('tool_ghostead', 'showsize');
if ($showsize) {
    scanner::add_sizes($rows);
}

$report = new \tool_ghostead\output\report(
    $PAGE->url,
    $categoryid,
    $rows,
    $result['total'],
    core_course_category::make_categories_list(),
    $showsize,
    (bool) $archiveok
);

if (!empty($rows)) {
    $PAGE->requires->js_call_amd('tool_ghostead/report', 'init', [[
        'selectall' => get_string('selectall', 'tool_ghostead'),
        'clear' => get_string('clearselection', 'tool_ghostead'),
        'selected' => get_string('selected', 'tool_ghostead'),
        'hide' => get_string('hidebtn', 'tool_ghostead'),
        'archive' => get_string('archivebtn', 'tool_ghostead'),
        'confirm' => get_string('confirmarchive', 'tool_ghostead'),
        'courses' => get_string('courses'),
    ]]);
}

$output = $PAGE->get_renderer('tool_ghostead');
echo $output->header();
echo $output->heading(get_string('pluginname', 'tool_ghostead'));
echo $output->render($report);
echo $output->footer();
